-- --------------------------------------------------------------------------------
-- 
-- Oracle APEX source export file
-- 
-- The contents of this file are intended for review and analysis purposes only.
-- Developers must use the Application Builder to make modifications to an
-- application. Changes to this file will not be reflected in the application.
-- 
-- --------------------------------------------------------------------------------

-- ----------------------------------------
-- Page: 2 - Offense Category > Region: Offense Category > Source > SQL Query

select OFFENSE_CAT_ID,
       OFFENSE_CAT_NAME,
       OFFENSE_CAT_NOTE,
       'Edit' EDIT
  from OFFENSE_CATEGORY;

