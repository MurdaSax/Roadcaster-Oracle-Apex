-- --------------------------------------------------------------------------------
-- 
-- Oracle APEX source export file
-- 
-- The contents of this file are intended for review and analysis purposes only.
-- Developers must use the Application Builder to make modifications to an
-- application. Changes to this file will not be reflected in the application.
-- 
-- --------------------------------------------------------------------------------

-- ----------------------------------------
-- Page: 10 - Overdue Violations > Region: Overdue Tickets > Source > SQL Query

select VIOLATION_ID,
       OCCURANCE_DATE,
       INCIDENT_DESCRIPTION,
       OFFENSE_ID,
       VEHICLE_REG_NUMBER,
       VECHICLE_OWNER,
       FINE_AMOUNT,
       DATE_DUE,
       STATUS,
       OFFENSE_NAME,
       OFFENSE_CAT_NAME,
       STATUS_DESC
  from VW_VIOLATIONS
    WHERE NVL(STATUS, 'N') = 'N' AND DATE_DUE < TO_DATE(SYSDATE);

