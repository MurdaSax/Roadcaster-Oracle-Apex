-- --------------------------------------------------------------------------------
-- 
-- Oracle APEX source export file
-- 
-- The contents of this file are intended for review and analysis purposes only.
-- Developers must use the Application Builder to make modifications to an
-- application. Changes to this file will not be reflected in the application.
-- 
-- --------------------------------------------------------------------------------

-- ----------------------------------------
-- Page: 23 - Violation Evidence > Region: Violation Evidence > Source > SQL Query

select "EVIDENCE_ID","VIOLATION_ID","FILE_NAME",sys.dbms_lob.getlength("IMAGE_FILE")"IMAGE_FILE","MIME_TYPE"from "VIOLATION_EVIDENCE";

