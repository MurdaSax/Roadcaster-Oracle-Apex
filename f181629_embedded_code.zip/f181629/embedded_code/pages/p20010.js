// --------------------------------------------------------------------------------
// 
// Oracle APEX source export file
// 
// The contents of this file are intended for review and analysis purposes only.
// Developers must use the Application Builder to make modifications to an
// application. Changes to this file will not be reflected in the application.
// 
// --------------------------------------------------------------------------------

// ----------------------------------------
// Page: 20010 - Push Notifications > JavaScript > Execute when Page Loads

apex.pwa.initPushSubscriptionPage();

// ----------------------------------------
// Page: 20010 - Push Notifications > Dynamic Action: Change P20010_ENABLE_PUSH > Action: Subscribe to push notifications > Settings > Code

apex.pwa.subscribePushNotifications();

// ----------------------------------------
// Page: 20010 - Push Notifications > Dynamic Action: Change P20010_ENABLE_PUSH > Action: Unsubscribe from push notifications > Settings > Code

apex.pwa.unsubscribePushNotifications();

