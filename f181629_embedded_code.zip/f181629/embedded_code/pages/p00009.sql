-- --------------------------------------------------------------------------------
-- 
-- Oracle APEX source export file
-- 
-- The contents of this file are intended for review and analysis purposes only.
-- Developers must use the Application Builder to make modifications to an
-- application. Changes to this file will not be reflected in the application.
-- 
-- --------------------------------------------------------------------------------

-- ----------------------------------------
-- Page: 9 - Offenses > Region: Offenses > Source > SQL Query

select o.OFFENSE_ID,
       o.OFFENSE_CAT_ID,
       o.OFFENSE_NAME,
       o.OFFENSE_DESC,
       o.PENALTY_POINTS,
       c.OFFENSE_CAT_NAME,
       'Edit' Edit
  from OFFENSES o INNER JOIN OFFENSE_CATEGORY c 
    ON o.OFFENSE_CAT_ID = c.OFFENSE_CAT_ID;

