-- --------------------------------------------------------------------------------
-- 
-- Oracle APEX source export file
-- 
-- The contents of this file are intended for review and analysis purposes only.
-- Developers must use the Application Builder to make modifications to an
-- application. Changes to this file will not be reflected in the application.
-- 
-- --------------------------------------------------------------------------------

-- ----------------------------------------
-- Page: 16 - Violations Dashboard > Region: Chart 2 > Attributes:  > Series: Series 1 > Source > SQL Query

select 'Label 1' label, 30 value from sys.dual
union all
select 'Label 2' label, 20 value from sys.dual
union all
select 'Label 3' label, 34 value from sys.dual
union all
select 'Label 4' label, 6  value from sys.dual
union all
select 'Label 5' label, 10 value from sys.dual;

-- ----------------------------------------
-- Page: 16 - Violations Dashboard > Region: Chart 4 > Attributes:  > Series: Series 1 > Source > SQL Query

select 'Label 1' label, 30 value from sys.dual
union all
select 'Label 2' label, 20 value from sys.dual
union all
select 'Label 3' label, 34 value from sys.dual
union all
select 'Label 4' label, 6  value from sys.dual
union all
select 'Label 5' label, 10 value from sys.dual;

-- ----------------------------------------
-- Page: 16 - Violations Dashboard > Region: Chart 3 > Attributes:  > Series: Series 1 > Source > SQL Query

select 'Label 1' label, 30 value from sys.dual
union all
select 'Label 2' label, 20 value from sys.dual
union all
select 'Label 3' label, 34 value from sys.dual
union all
select 'Label 4' label, 6  value from sys.dual
union all
select 'Label 5' label, 10 value from sys.dual;

