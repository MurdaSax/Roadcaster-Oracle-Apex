-- --------------------------------------------------------------------------------
-- 
-- Oracle APEX source export file
-- 
-- The contents of this file are intended for review and analysis purposes only.
-- Developers must use the Application Builder to make modifications to an
-- application. Changes to this file will not be reflected in the application.
-- 
-- --------------------------------------------------------------------------------

-- ----------------------------------------
-- Page: 15 - Add/Edit Violation > Dynamic Action: CalculateFineAmount > Action: Set Value > Settings > PL/SQL Function Body

DECLARE
    v_amount number;
BEGIN
    v_amount := pk_violations.calculate_penalty_amount(:P15_OFFENSE_ID);

    return v_amount;
END;

