-- --------------------------------------------------------------------------------
-- 
-- Oracle APEX source export file
-- 
-- The contents of this file are intended for review and analysis purposes only.
-- Developers must use the Application Builder to make modifications to an
-- application. Changes to this file will not be reflected in the application.
-- 
-- --------------------------------------------------------------------------------

-- ----------------------------------------
-- Page: 1 - Home > Region: Violations > Source > SQL Query

Select 1 level_value,
        'Total Violations' Label,
        'f?p=&APP_ID.:13:APP_SESSION.::::' as target,
        COUNT(violation_id) attr1  
    from violations

union

Select 1 level_value, 
        'Paid Tickets' Label,
        'f?p=&APP_ID.:13:APP_SESSION.::::' as target,
        COUNT(violation_id) attr1 
    from violations where NVL(status, 'N') = 'Y'

union

Select 1 level_value,
        'Unpaid Tickets' Label,
        'f?p=&APP_ID.:13:APP_SESSION.::::' as target,
         COUNT(violation_id) attr1   
    from violations where NVL(status, 'N') = 'N'
union

Select 1 level_value,
        'Over Due Payments' Label,
        'f?p=&APP_ID.:13:APP_SESSION.::::' as target,
        COUNT(violation_id) attr1
         from violations where NVL(status, 'N') = 'N' and DATE_DUE < TO_DATE(SYSDATE);

-- ----------------------------------------
-- Page: 1 - Home > Region: Violation Categories > Attributes:  > Series: Violation Categories > Source > SQL Query

Select OFFENSE_CAT_NAME LABEL, COUNT(VIOLATION_ID) CNT FROM vw_violations
    GROUP BY OFFENSE_CAT_NAME;

